from pathlib import Path
import csv,json,math,hashlib,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,colors
from matplotlib.collections import LineCollection
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from collections import Counter
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor

ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'completed_output';OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,'savefig.facecolor':'white'})
G=['Lake','Sediment','Groundwater'];LABEL={'Lake':'Lake 湖水受体','Sediment':'Sediment 沉积物','Groundwater':'Groundwater 地下水'}
COL={'Lake':'#177D99','Sediment':'#BC643E','Groundwater':'#546CB0'};GOLD='#DF9C2E';INK='#203247'
def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def csvout(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
ms={g:read(DATA/g/'molecule_transformation_counts.csv') for g in G}
pairs={g:read(DATA/g/'transformation_pairs_23_columns.csv') for g in G}
summary={r['group']:r for r in read(DATA/'group_summary.csv')}
figures=[]
def save(fig,name,title,place,caption):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/(name+'.'+ext),dpi=220,bbox_inches='tight')
 plt.close(fig);figures.append({'file':name,'title':title,'placement':place,'caption':caption})
def footer(fig,text):fig.text(.035,.02,text,fontsize=9,color='#607080',va='bottom')

# 1. Methods flow: distinguish processing, source selection and receptor checking.
fig=plt.figure(figsize=(14,8));ax=fig.add_axes([.03,.1,.94,.8]);ax.set_axis_off()
fig.suptitle('从原始峰表到 Lake 可检出的来源独有候选',x=.04,ha='left',fontsize=22,color=INK)
boxes=[(.02,.69,.28,.20,'① 保留原始数据 · 按来源合并','Lake 3 样 / Sediment 3 样 / 地下水 6 样\n保留样本名、实测 m/z、原始峰强'),(.36,.69,.28,.20,'② 质量与分子式筛选','200 ≤ 实测 m/z ≤ 900，峰强 > 0\n组内按分子式去重；质量取样本中位数\n再筛 N > 0 且 H/C < 1.5'),(.70,.69,.28,.20,'③ 每组只计算一次网络','原始 1,255 条转化数据库\n±0.000010 Da，含端点，整数匹配\n一条边 = 一个不同分子对'),(.70,.27,.28,.23,'④ 按连接的不同分子数筛选','逐分子连接数 k：未匹配记 0\nRI 初筛池：k ≤ 1\nmarker 主筛池：k = 0'),(.36,.27,.28,.23,'⑤ 排除其他真实来源共有分子','地下水候选排除沉积物检出分子式\n沉积物候选排除地下水检出分子式\nLake 不参与来源排除'),(.02,.27,.28,.23,'⑥ 仅保留 Lake 中确有检出','地下水独有且 Lake 检出：19 个\n沉积物独有且 Lake 检出：6 个\n保留 Lake 样本名单及原始峰强')]
for i,(x,y,w,h,title,text) in enumerate(boxes):
 fc='#F0F5F8' if i<5 else '#FFF5E5'
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.012',facecolor=fc,edgecolor='#CDD8E0',lw=1.2))
 ax.text(x+.015,y+h-.035,title,fontsize=12,fontweight='bold',color=INK,va='top')
 ax.text(x+.015,y+h-.095,text,fontsize=10,linespacing=1.65,color='#35485C',va='top')
for a,b in [((.305,.79),(.35,.79)),((.645,.79),(.69,.79)),((.84,.675),(.84,.52)),((.69,.385),(.65,.385)),((.35,.385),(.31,.385))]:
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=18,lw=1.7,color='#6A7F91'))
ax.text(.02,.10,'最终候选：共 25 个；均为来源组 k = 0、另一真实来源未检出、Lake 至少 1 个样本检出。',fontsize=13,fontweight='bold',color=INK)
footer(fig,'Lake 检出只说明受体中可找到该分子式；稳定性、来源代表性和定量贡献尚需独立验证。')
save(fig,'01_分析流程与筛选规则','分析做了哪些步骤','方法部分开头；先交代完整筛选逻辑。','按来源独立建网，再以来源零连接、其他来源未检出及Lake检出三个条件筛选候选。')

# 2. Actual networks in measured-mass / H:C coordinates, all nodes and all edges.
fig,axs=plt.subplots(1,3,figsize=(15,6.3),sharex=True,sharey=True)
for ax,g in zip(axs,G):
 lookup={r['formula']:r for r in ms[g]};coords={f:(float(r['representative_measured_mz']),float(r['H/C'])) for f,r in lookup.items()}
 segments=[(coords[r['formula_x']],coords[r['formula_y']]) for r in pairs[g]]
 ax.add_collection(LineCollection(segments,colors=COL[g],linewidths=.25,alpha=.025,rasterized=True))
 connected=[coords[f] for f,r in lookup.items() if int(r['transformation_count'])>0];isolated=[coords[f] for f,r in lookup.items() if int(r['transformation_count'])==0]
 a=np.array(connected);b=np.array(isolated)
 ax.scatter(a[:,0],a[:,1],s=4,color=COL[g],alpha=.55,rasterized=True)
 ax.scatter(b[:,0],b[:,1],s=13,facecolors='none',edgecolors=GOLD,linewidths=.7,label='k = 0')
 ax.set_title(f'{LABEL[g]}\n{len(ms[g]):,} 分子 · {len(pairs[g]):,} 峰对',fontsize=12,color=INK)
 ax.set_xlim(195,905);ax.set_ylim(-.03,1.52);ax.set_xlabel('实测代表 m/z（Da）');ax.grid(alpha=.15)
 ax.legend(loc='lower right',frameon=False,fontsize=9)
axs[0].set_ylabel('H/C')
fig.suptitle('三个分组的实际分子转化网络',x=.04,ha='left',fontsize=21,color=INK)
fig.subplots_adjust(top=.77,bottom=.20,wspace=.10)
footer(fig,'全量节点与峰对均绘出，未抽样。坐标为实测代表质量与 H/C；边仅表示数据库质量差命中，不证明反应发生或方向。\n金色空心点为该组零连接分子；密集连线已降低透明度，图上位置不表示系统发育关系。')
save(fig,'02_三个组的实际转化网络','各组建立了怎样的转化网络','结果部分第一张；与节点/峰对总量一起呈现。','每组仅建一次网络，节点为筛后分子式，连线为唯一匹配分子对；全部94951条边保留。')
csvout('02_网络规模.csv',[{'group':g,'molecules':len(ms[g]),'unique_edges':len(pairs[g]),'zero_degree':sum(int(r['transformation_count'])==0 for r in ms[g])} for g in G])

# 3. Degree distributions with exact categories. Counts and normalized percent.
fig,(ax,bx)=plt.subplots(1,2,figsize=(14,6),gridspec_kw={'width_ratios':[1.5,1]})
categories=['0','1','2–5','6–10','11–20','>20'];rows=[]
for j,g in enumerate(G):
 ds=[int(r['transformation_count']) for r in ms[g]]
 cs=[sum(d==0 for d in ds),sum(d==1 for d in ds),sum(2<=d<=5 for d in ds),sum(6<=d<=10 for d in ds),sum(11<=d<=20 for d in ds),sum(d>20 for d in ds)]
 ax.bar(np.arange(6)+(j-1)*.25,np.array(cs)/len(ds)*100,.23,label=LABEL[g],color=COL[g])
 for c,n in zip(categories,cs):rows.append({'group':g,'degree_category':c,'molecules':n,'percent':n/len(ds)*100})
ax.set_xticks(range(6),categories);ax.set_xlabel('每个分子连接的不同分子数 k');ax.set_ylabel('占该组网络分子的比例（%）');ax.legend(frameon=False,fontsize=10);ax.grid(axis='y',alpha=.2)
xx=np.arange(3);ri=[sum(int(r['transformation_count'])<=1 for r in ms[g]) for g in G];zero=[sum(int(r['transformation_count'])==0 for r in ms[g]) for g in G]
bx.bar(xx-.16,ri,.30,color='#9FB2C1',label='RI 池 k ≤ 1');bx.bar(xx+.16,zero,.30,color=GOLD,label='marker 池 k = 0')
for x,a,b in zip(xx,ri,zero):bx.text(x-.16,a+4,str(a),ha='center');bx.text(x+.16,b+4,str(b),ha='center')
bx.set_xticks(xx,['Lake','Sediment','Groundwater']);bx.set_ylabel('分子式数');bx.set_ylim(0,max(ri)*1.25);bx.legend(frameon=False,fontsize=10);bx.grid(axis='y',alpha=.2)
fig.suptitle('从连接次数分布到 RI / marker 初筛池',x=.04,ha='left',fontsize=21,color=INK)
fig.subplots_adjust(top=.80,bottom=.20,wspace=.25)
footer(fig,'转化次数按不同分子对计数；多数据库条目命中同一对不重复计数。右图为来源排除与 Lake 检出筛选之前的池大小。\nLake 的零连接池仅作网络描述；不是“Lake 来源独有 marker”。')
save(fig,'03_转化次数分布与初筛池','为什么选择这些 RI / marker 候选','结果部分第二张；展示从网络走到候选池的依据。','将次数分为0、1、2–5、6–10、11–20和>20，并同时报告≤1和=0池的真实规模。')
csvout('03_连接次数分布.csv',rows)

# 4. Transformation labels: last DB match per unique edge, count top 8 per group.
fig,axs=plt.subplots(1,3,figsize=(15,6.5));rows=[]
for ax,g in zip(axs,G):
 counts=Counter(r['Trans.name'] for r in pairs[g]);top=counts.most_common(8)
 names=[n for n,v in top][::-1];vals=[v for n,v in top][::-1]
 ax.barh(names,vals,color=COL[g],height=.65)
 for y,v in enumerate(vals):ax.text(v+max(vals)*.02,y,f'{v:,}',va='center',fontsize=9)
 ax.set_xlim(0,max(vals)*1.22);ax.set_xlabel('不同匹配峰对数');ax.set_title(LABEL[g],fontsize=12,color=INK);ax.grid(axis='x',alpha=.15)
 rows.extend({'group':g,'transformation_name':n,'unique_pairs':v,'fraction_of_group_edges':v/len(pairs[g])} for n,v in counts.most_common())
fig.suptitle('各组最常见的质量差匹配标注（Top 8）',x=.04,ha='left',fontsize=21,color=INK)
fig.subplots_adjust(top=.79,bottom=.22,wspace=.58,left=.09,right=.97)
footer(fig,'Trans.name 保留原数据库命名；同一峰对多条命中时采用数据库最后一条，并另有全命中审计表。\n柱长是匹配峰对数，不是反应速率或实测反应次数；三个面板横轴独立，组间比较应结合网络规模。')
save(fig,'04_主要转化质量差标注','网络主要包含哪些质量差匹配','结果补充页；篇幅不足可移至补充材料。','按各组唯一峰对的最终Trans.name统计Top 8；完整频次作为CSV提供。')
csvout('04_全部转化名称频次.csv',rows)

# 5. 25 final source-unique candidates that were truly found in Lake.
rs=[]
for g in ['Groundwater','Sediment']:
 chosen=[r for r in read(DATA/g/'source_unique_marker_candidates.csv') if int(r['lake_detection_count'])>0]
 chosen.sort(key=lambda r:(-int(r['lake_detection_count']),r['formula']))
 rs.extend(chosen)
samples=['K1-shui_result','K2-shui_result','K3-shui_result']
raw=np.array([[float(r.get('lake_raw_intensity::'+s) or np.nan) for s in samples] for r in rs]);logged=np.log10(raw)
fig=plt.figure(figsize=(12,11));ax=fig.add_axes([.29,.12,.49,.74]);cax=fig.add_axes([.82,.38,.022,.30])
cmap=plt.colormaps['YlGnBu'].copy();cmap.set_bad('#EAECEF')
im=ax.imshow(np.ma.masked_invalid(logged),aspect='auto',cmap=cmap,vmin=np.nanmin(logged),vmax=np.nanmax(logged))
labels=[r['formula'] for r in rs]
ax.set_yticks(range(len(rs)),labels,fontsize=10);ax.set_xticks(range(3),['Lake K1','Lake K2','Lake K3'],fontsize=12);ax.xaxis.tick_top()
for tick,r in zip(ax.get_yticklabels(),rs):tick.set_color(COL[r['group']])
for y,r in enumerate(rs):
 for x in range(3):
  text='—' if np.isnan(raw[y,x]) else f'{raw[y,x]/1e6:.2f}'
  ax.text(x,y,text,ha='center',va='center',fontsize=9,color='white' if np.isfinite(logged[y,x]) and logged[y,x]>(np.nanmin(logged)+np.nanmax(logged))/2 else INK)
ax.axhline(18.5,color='white',lw=4);ax.set_xticks(np.arange(-.5,3,1),minor=True);ax.set_yticks(np.arange(-.5,len(rs),1),minor=True);ax.grid(which='minor',color='white',lw=.8);ax.tick_params(which='minor',bottom=False,left=False)
cb=fig.colorbar(im,cax=cax);cb.set_label('log10（原始峰强）',fontsize=10)
fig.text(.04,.96,'在 Lake 中找到的来源独有 marker 候选',fontsize=21,color=INK,fontweight='bold')
fig.text(.04,.923,'地下水 19 个  ·  沉积物 6 个  |  来源 k = 0，另一来源未检出',fontsize=12,color='#506070')
fig.text(.82,.84,'地下水独有：19',color=COL['Groundwater'],fontsize=12,fontweight='bold');fig.text(.82,.80,'沉积物独有：6',color=COL['Sediment'],fontsize=12,fontweight='bold')
fig.text(.82,.22,'单元格数字\n= 原始峰强 ÷ 10^6\n灰色 / — = 未检出\n颜色未经行归一化',fontsize=10,linespacing=1.7,color=INK)
footer(fig,'“独有”指相对另一个真实来源；候选在来源端元与 Lake 受体中均检出。筛选不要求三个 Lake 样本全部检出。\n峰强未归一化，只作原始检出核查；不同样本的绝对峰强不可直接解释为来源贡献。湖水检出 ≠ 稳定性验证。')
save(fig,'05_Lake检出来源独有候选热图','最终哪些来源候选在 Lake 中找到','核心结果页；建议放在结论前。','25个候选全部展示，行颜色区分来源，色阶为Lake原始峰强的log10，格内显示原始峰强/10^6；灰色表示未检出。')
csvout('05_Lake候选热图原始数据.csv',[{'source':r['group'],'formula':r['formula'],'source_degree':r['transformation_count'],'lake_detection_count':r['lake_detection_count'],'lake_detection_samples':r['lake_detection_samples'],**{s:r.get('lake_raw_intensity::'+s,'') for s in samples}} for r in rs])

# PPT: each figure has placement and interpretation notes, no speculative claims.
prs=Presentation();prs.slide_width=Inches(16);prs.slide_height=Inches(9)
for item in figures:
 slide=prs.slides.add_slide(prs.slide_layouts[6]);slide.background.fill.solid();slide.background.fill.fore_color.rgb=RGBColor(255,255,255)
 box=slide.shapes.add_textbox(Inches(.4),Inches(.12),Inches(15.2),Inches(.5));p=box.text_frame.paragraphs[0];p.text=item['title'];p.font.size=Pt(23);p.font.bold=True;p.font.color.rgb=RGBColor.from_string('203247')
 from PIL import Image
 image=OUT/(item['file']+'.png');ww,hh=Image.open(image).size
 maxw,maxh=15.1,7.35;scale=min(maxw/ww,maxh/hh);wi,he=ww*scale,hh*scale
 slide.shapes.add_picture(str(image),Inches((16-wi)/2),Inches(.7+(7.35-he)/2),width=Inches(wi),height=Inches(he))
 box=slide.shapes.add_textbox(Inches(.45),Inches(8.25),Inches(15.1),Inches(.5));p=box.text_frame.paragraphs[0];p.text='建议位置：'+item['placement'];p.font.size=Pt(13);p.font.color.rgb=RGBColor.from_string('506070')
 slide.notes_slide.notes_text_frame.text=item['caption']+'\n'+item['placement']
prs.save(OUT/'密云_分子转化分析图组.pptx')
(OUT/'figure_manifest.json').write_text(json.dumps(figures,ensure_ascii=False,indent=2))
readme='# 分子转化图组：怎么放\n\n推荐正文放图1、2、3、5；图4作为转化质量差标注的补充结果。PPT已按1→5排好，保留全部五页，可按用途删页。\n\n'
for item in figures:readme+=f"## {item['file']}\n\n**{item['title']}**\n\n放置：{item['placement']}\n\n图注：{item['caption']}\n\n"
readme+='所有图来自实际结果；PNG供PPT使用，PDF/SVG供矢量编辑，CSV为图中数据，代码可复现。网络图绘出全部节点及全部真实边，边在SVG/PDF中栅格化以控制文件大小，其余文字与节点保持矢量。图2不采用虚构的网络布局；坐标为真实代表m/z和H/C。图4是质量差匹配标注，不代表反应被证实发生。图5只显示Lake内实际检出的25个来源独有候选，不作稳定性或定量贡献结论。\n'
(OUT/'图的放置与图注.md').write_text(readme)
(OUT/'plot_miyun_results.py').write_bytes(Path(__file__).read_bytes())
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt')
(OUT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
with zipfile.ZipFile(ROOT/'密云_分子转化图组.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.iterdir()):
  if p.is_file():z.write(p,p.name)
print('Created',len(figures),'figures; PNG/SVG/PDF; 5-slide PPT; underlying data and plotting code')
