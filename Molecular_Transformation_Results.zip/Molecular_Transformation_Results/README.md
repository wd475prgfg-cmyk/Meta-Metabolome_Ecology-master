# Shoreline 分子转化结果

本目录只对应 PPT 第 1–5 页的分子转化步骤。压缩包已含处理后的
`Processed_Shoreline_FTICR_Data_clean.csv` 和
`Processed_Shoreline_FTICR_Mol_clean.csv`；仓库内的说明指出它们由
`FTMS_Analysis.R` 处理并剔除了校准不佳的样本。因此直接从这两个现成文件及
`Transformation_Database_07-2020.csv` 计算逐样本分子转化。

原 `Transformation_Analysis_by_Sample.R` 使用作者电脑的绝对路径，而且其
`*_Data.csv`、`*_Mol.csv` 匹配模式与现成 `_clean.csv` 文件名不符。
本目录由仓库根目录的 `run_molecular_transformations.py` 生成，明确指定输入文件，
并遵循原 R 脚本的匹配规则：只取样本中强度大于零的峰、`peak.x > peak.y`，
质量差与数据库质量的偏差在闭区间 ±0.000010 Da 内。同一个峰对命中多个数据库
条目时，采用数据库中最后一条的名称。

- `Transformation Peak Comparisons/Shoreline/`：22 个逐样本 CSV，保留原 R
  脚本的 7 列格式：`sample, Dist, peak.x, peak.y, Dist.plus, Dist.minus, Trans.name`。
- `Annotated Peak Comparisons/Shoreline/`：同样的 22 个峰对表，另按 PPT 示例
  用 Mol 文件中的 Mass 对应 C/H/O/N/P/S、`MolForm` 和 `Class`。未有分子式的
  峰保留原文件中的 `NA`；没有推测缺失的分子式。
- `All_Samples_Annotated_Transformations.csv`：将上述 22 张注释表合并成一张
  23 列表，可直接用 Excel 打开；`sample` 列标明所属样本。
- `All_Samples_Annotated_Transformations.xlsx`：同一张合并表的 Excel 工作簿，
  可直接双击打开，含 91,379 行结果。
- `sample_summary.csv`：每个样本的有峰质量数、匹配峰对数，以及两端都有
  分子式的峰对数，用于核查结果。

共得到 91,379 个逐样本匹配峰对，其中 82,625 个峰对的两端均有已记录的
分子式。22 个样本的结果均用另一种逐样本全峰对计算独立核对了峰对、转化名称
及分子注释。转化名称是基于质量差的候选标注；`peak.x` 为较大质量峰，按 PPT
示例标为转换前，`peak.y` 为较小质量峰，标为转换后。这个标记不证明实际反应方向。

在仓库根目录使用 `python3 run_molecular_transformations.py` 可重新生成结果；
需要 Python 3 和 NumPy。本次未做 PPT 第 6 页以后的 RI、marker、溯源或群落组装分析。
