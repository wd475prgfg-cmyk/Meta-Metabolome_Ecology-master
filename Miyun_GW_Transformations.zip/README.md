# 密云地下水与湖泊样本：分子转化结果

本结果使用上传的 `九月密云_GW_6样合并.xlsx` 与 `Lake.zip`，只执行 PPT 第 1–5 页的逐样本分子转化。地下水工作簿的 `ALL_6_GW` 页与 6 张单样本页完全相同，因此仅计算 6 张单样本页；湖泊压缩包含 50 个样本文件。没有把不同样本或两个端元的峰互相配对。

使用 `meas.m/z` 作为 Mass，Excel 中的质量精度为小数点后 6 位。按仓库 `FTMS_Analysis.R` 的质量范围，保留 200–900 Da 的峰（边界包含）；地下水剔除 125 个、湖泊剔除 1,239 个低于 200 Da 的峰。源表已有峰强、分子式和 C/H/O/N/P/S 元素数；`Class` 列缺失，注释表中记为 `None`。源表没有 `C13` 同位素指示列，无法核实同位素过滤，因此转化是基于提供的分子峰计算。源表的 `RI` 列未用于计算。

每个样本只用峰强大于零的两个峰计算正质量差 `peak.x - peak.y`，在转化数据库的质量值 ±0.000010 Da 闭区间内匹配。若同一个峰对匹配多条转化记录，沿用原分析脚本的规则，保留数据库中最后一条的名称。`peak.x` 是较大质量峰；这些转化是质量差支持的候选标注，不能由此确定真实反应方向。

## 结果

| 端元 | 样本数 | 保留峰数 | 匹配峰对数 |
| --- | ---: | ---: | ---: |
| GW（地下水） | 6 | 23,233 | 514,654 |
| Lake（湖泊） | 50 | 231,595 | 5,637,768 |

`GW/` 和 `Lake/` 各含两个目录：

- `Transformation Peak Comparisons/`：与原 R 脚本一致的 7 列逐样本 CSV（sample、Dist、peak.x、peak.y、Dist.plus、Dist.minus、Trans.name）。
- `Annotated Peak Comparisons/`：与 PPT 截图一致的 23 列逐样本 CSV，另含前后两个峰的元素数、分子式和类别。可逐个用 Excel 打开。湖泊总结果超过 Excel 单工作表的行数上限，所以按 50 个样本分文件保存。

`sample_summary.csv` 和 `sample_summary.xlsx` 给出每个样本的输入峰数、筛选峰数及转化峰对数。它们仅用于核对本轮运算，没有生成每峰转化次数、RI、marker 或溯源结果。

`run_miyun_transformations.py` 是本次处理脚本，调用同目录的 `run_molecular_transformations.py`；`Transformation_Database_07-2020.csv` 是使用的转化数据库。复算需 Python 3、NumPy、openpyxl 和最初上传的两个输入文件，在同目录执行：

```bash
python3 run_miyun_transformations.py --groundwater '九月密云_GW_6样合并.xlsx' --lake-zip Lake.zip --output-dir results
```

云环境无法直接写入用户电脑上的 `C:\Users\86152\Desktop\氮素溯源\2026.10开题\miyun`。下载结果压缩包后，可在电脑上解压到该目录。
